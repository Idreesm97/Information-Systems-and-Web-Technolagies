﻿<?php
include "database-Handler.php";
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="update_DatabaseStyleSheet.css">
	<style media="screen">
     .error{color: #FF0000;}
     </style>
    <meta charset="utf-8" />
    <title>Update Database</title>
</head>
<body>
<a href="index.php"><h1>Update Data Page</h1></a>
	<?php
     $idsearch = $_POST['id'];
     $Firstname = $_POST['Firstname'];
     $Lastname = $_POST['Lastname'];
     $email = $_POST['email'];
     $studentID = $_POST['studentID'];
     //$location = $_POST['location'];

     $idsearchError = $FirstnameError = $LastnameError = $studentIDError = $emailError = $genderError = $locationError = "";

     if ($_SERVER['REQUEST_METHOD'] == "POST"){
       if (empty($idsearch)) {
         $idsearchError = "ID input is required";
       }
       else {
         $idsearch = test_input($idsearch);
         if (!preg_match("/^[1-9][0-9]{2,10}$/", $studentID)) {
           $idsearchError = "Only numbers and white spaces are allowed";
         }
       }
       if (empty($_POST["Firstname"])) {
         $FirstnameError = "First name is required";
       }
       else {
         $Firstname = test_input($_POST["Firstname"]);
         if  (!preg_match("/^[a-zA-Z]{2,20}$/", $Firstname)) {
           $FirstnameError = "Only letters and white spaces are allowed";
         }
       }
       if (empty($Lastname)) {
         $LastnameError = "Last name is required";
       }
       else {
         $Lastname = test_input($Lastname);
         if (!preg_match("/^[a-zA-Z]{2,20}$/", $Lastname)) {
           $LastnameError = "Only letters and white spaces are allowed";
         }
       }
       if (empty($email)) {
         $emailError = "Email is required.";
       }
       else {
         $email = test_input($email);
         if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
           $emailError = "Invalid email format.";
         }
       }
       if (empty($studentID)) {
         $studentIDError = "Student ID is required.";
       }
       else {
         $studentID = test_input($studentID);
         if (!preg_match("/^[0-9]{9}$/", $studentID)) {
           $studentIDError = "Only numbers and whitespaces allowed";
         }
       }
       /*if (empty($_POST["location"])) {
         $locationError = "Location is required";
       }
       else {
         $location = test_input($_POST["location"]);
         if (!preg_match("/^[a-zA-Z]*$/", $location)) {
           $locationError = "Only letters and white spaces are allowed";
         }
       }*/
     }
     function test_input($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
     }

     if (isset($_POST['submit'])) {
      $idsearch = $_POST['id'];
	    $Firstname = $_POST['Firstname'];
      $Lastname = $_POST['Lastname'];
      $studentID = $_POST['studentID'];
      $email = $_POST['email'];
      //$location = $_POST['location'];

      $studentIDUserFinder = "SELECT studentIDUSERS FROM users WHERE studentIDUSERS LIKE $studentID";
      $studentnameQuery = sqlsrv_query($conn, $studentIDUserFinder);
      $studentnameFetch = sqlsrv_fetch_array($studentnameQuery);


       if (($FirstnameError == "") && ($LastnameError == "") && ($emailError == "") && ($studentIDError == "") && ($locationError == "")){
         //$query_id = "SELECT * FROM users WHERE ID = '$idsearch'";
         //$result_id = sqlsrv_query($query_id);
         //if(sqlsrv_query($result_id))
         //{
           if(empty($studentnameFetch))
           {
              echo "Student ID not Found";
           }
           else
           {
            $sql_fetch_update="UPDATE dbo.users SET firstnameUsers='$Firstname',lastnameUsers='$Lastname',
            emailUsers='$email',studentIDUSERS=$studentID /*location='$location'*/ WHERE ID=$idsearch";
   
            $result_update = sqlsrv_query($conn, $sql_fetch_update);
   
            if($result_update){
              echo "<br>";
             header("Location: SubmitConfirmationPageUpdate.php");
            }
            else {
              echo "<br>";
              echo "Records  Unsuccessfully";
              echo "<br>";
              die(print_r( sqlsrv_errors(), true));
            }
           }
        //}
        //else
        //{
        //  echo "ID doesn't exist";
        //}
      }
    }
       else {
         //echo "Input Error. Please try again.";
       }
      ?>
      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
        <section>
		<div class="input-container">
        <input class="input-field" type="text" placeholder="ID" name="id" required autocomplete="off">
        <span class="error">* <?php echo $idsearchError;?></span>
        <br><br>
		</div>
		<div class="input-container">
        <input class="input-field" type="text" placeholder="First Name" name="Firstname" required autocomplete="off">
        <span class="error">* <?php echo $FirstnameError;?></span>
        <br><br>
		</div>
		<div class="input-container">
        <input  class="input-field" type="text" placeholder="Last Name" name="Lastname" required autocomplete="off">
        <span class="error">* <?php echo $LastnameError;?></span>
        <br><br>
		</div>
		<div class="input-container">
        <input class="input-field" type="text" placeholder="Email" name="email" required autocomplete="off">
        <span class="error">* <?php echo $emailError;?></span>
        <br><br>
		</div>
		<div class="input-container">
        <input class="input-field" type="text" placeholder="Student ID" pattern="^[0-9]{9}$"  name="studentID" required autocomplete="off">
        <span class="error">* <?php echo $studentIDError;?></span>
        <br><br>
		</div>
		<!--<div class="input-container">
        <input class="input-field" type="text" placeholder="Location" name="location" required autocomplete="off">
        <span class="error">* <?php echo $locationError;?></span>
        <br><br>
		</div>-->
        <div class="mainIndex">
		<div class="sub-mainIndex">
         <button type="submit" name="submit" class="button-two" id="input-submit"><span>Update Something</span></button>
		</div>
		</div>
		</section>
      </form>
</body>
</html>