﻿<?php
include "database-Handler.php";
 ?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="IndexDesignPage.css">
    <meta charset="utf-8" />
	<title>Info Systems ACW</title>
	<style media="screen">
      .error{color: #FF0000;}
	  </style>
</head>
<body>
<h1>Input Data Page</h1>
<br><br><br>



 <?php

    $FirstnameError = $LastnameError = $studentIDError = $emailError = $genderError = $locationError ="";
    $Firstname = $Lastname = $studentID = $email = $gender = $location= "";

    if ($_SERVER['REQUEST_METHOD'] == "POST"){
      if (empty($_POST["Firstname"])) {
        $FirstnameError = "First name is required";
      }
      else {
        $Firstname = test_input($_POST["Firstname"]);
        if (!preg_match("/^[a-zA-Z]{2,20}$/", $Firstname)) {
          $FirstnameError = "Only letters and white spaces are allowed and outside the length boundary";
        }
      
      }
      if (empty($_POST["Lastname"])) {
        $LastnameError = "Last name is required";
      }
      else {
        $Lastname = test_input($_POST["Lastname"]);
        if (!preg_match("/^[a-zA-Z ]{2,20}$/", $Lastname)) {
          $LastnameError = "Only letter and white spaces allowed and outside the length boundary";
        }
      }
      if (empty($_POST["email"])) {
        $emailError = "Email is required.";
      }
      else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $emailError = "Invalid email format and outside the length boundary.";
        }
      }
      if (empty($_POST["studentID"])) {
        $studentIDError = "Student ID is required.";
      }
      else {
        $studentID = test_input($_POST["studentID"]);
        if (!preg_match("/^[0-9]{9}$/", $studentID)) {
          $studentIDError = "Only numbers and whitespaces allowed and outside the length boundary";
        }
      }
      if (empty($_POST["Location"])) {
        $locationError = "Location is required";
      }
      else {
        $location = test_input($_POST["Location"]);
        if (!preg_match("/^[a-zA-Z]{2,20}$/", $location)) {
          $locationError = "Only letters and white spaces are allowed and outside the length boundary";
        }
      }
     
    }
    $ipAddress;
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
      }
      elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
      }
      else {
        $ipAddress = $_SERVER['REMOTE_ADDR'];
      }
      date_default_timezone_set('Europe/London');
      $date = date('Y-m-d H:i:s');

    function test_input($data){
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
    if (isset($_POST['submit'])) {

      $Firstname = $_POST['Firstname'];
      $Lastname = $_POST['Lastname'];
      $studentID = $_POST['studentID'];
      $email = $_POST['email'];
      $location = $_POST['Location'];

      $duplicate = "SELECT * FROM users WHERE studentIDUSERS = '$studentID'";
      $result_dup = sqlsrv_query($conn, $duplicate);
      $result_query = sqlsrv_fetch_array($result_dup);

      if($result_query > 0)
      {
        echo "Error repeated Input";
      }
      else
      {
        echo "Successful Input";
        if (($FirstnameError=="") && ($LastnameError=="") && ($emailError=="") && ($studentIDError=="") && ($locationError=="")) {
          $tsql= "INSERT INTO dbo.users (
                  firstnameUsers,
                  lastnameUsers,
                  emailUsers,
                  studentIDUSERS,
                  ipAddressUsers,
                  dateUsers,
            location
            ) 
                  VALUES
                  ('$Firstname', '$Lastname', '$email', '$studentID', '$ipAddress', '$date', '$location');";
                  /*$var = array($Firstname, $Lastname, $email, $studentID, $ipAddress, $date, $location);*/
                  if (!sqlsrv_query($conn, $tsql))
                       {
                  die(print_r( sqlsrv_errors(), true));
                  }
            else {
            header("Location: SubmitConfirmationPage.php");
            //echo "SUCCESSFUL";
            }     
            }
            else {
              echo "data not inserted into database";
            } 
      }
    }
     ?>
     <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
       <section>
         <div class="input-container">
         <input class="input-field" type="text" name="Firstname" placeholder="FirstName" id="input-Firstname" required autocomplete="off"  value="<?php echo $Firstname;?>">
         <span class="error">* <?php echo $FirstnameError;?></span>
         <br><br>
       </div>
       <div class="input-container">
         <input class="input-field" type="text" name="Lastname" placeholder="Last Name" id="input-Lastname" required autocomplete="off"  value="<?php echo $Lastname;?>">
         <span class="error">* <?php echo $LastnameError;?></span>
         <br><br>
       </div>
       <div class="input-container">
         <input class="input-field" type="text" name="email" placeholder="Email" id="input-Email" required autocomplete="off"  value="<?php echo $email;?>">
         <span class="error">* <?php echo $emailError;?></span>
         <br><br>
       </div>
       <div class="input-container">
         <input class="input-field" type="text" name="studentID" placeholder="Student ID" id="input-StudentID" required autocomplete="off" pattern="^[0-9]{9}$"  value="<?php echo $studentID;?>">
         <span class="error">* <?php echo $studentIDError;?></span>
         <br><br>
       </div>
       <div class="input-container">
         <input class="input-field" type="text" name="Location" placeholder="Location" id="input-Location" required autocomplete="off"  value="<?php echo $location;?>">
         <span class="error">* <?php echo $locationError;?></span>
         <br><br>
       </div>
       <br><br>
       <div class="mainIndex">
       <div class="sub-mainIndex">
         <button type="submit" name="submit" class="button-two" id="input-submit"><span>Submit Something</span></button>
       </div>
     </div>
      <nav>
        <ul>
        <a class="active" href="index.php"><li>Insert Data</li></a>
        <a href="fetch-database-Handler.php"><li>Show Data</li></a>
        <a href="update_Database-Handler.php"><li>Update Student Information</li></a>
        <a href="changeLocation.php"><li>Update Student Location</li></a>
        <a href="location.php"><li>Search Last 24Hrs</li></a>
      </ul>
    </nav>
</body>
</html>