﻿<?php
	$dbServername = 'sql.rde.hull.ac.uk';
	$conn_Info = array('Database' => 'rde_538629');
	$conn = sqlsrv_connect($dbServername, $conn_Info);
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="TablePageDesign.css">
    <meta charset="utf-8" />
    <title>Fetching Stored Data</title>
</head>
<body>
 <form action="fetch-database-Handler.php" method="get">
     <section>
       <a href="index.php"> <h1>Fetch Stored Data</h1></a>
       <input type="text" name="valueSearch" id="Search-bar" pattern="^[A-Za-z0-9_]{1,20}$" placeholder="Enter Value To Search"><br><br>
       <div class="main">
       <div class="sub-main">
         <button type="submit" name="Search" class="button-two" id="search-button"><span>Search Something</span></button>
       </div>
     </div>
        <br><br><br><br><br><br><br>
       <div class="tbl-header">
         <table cellpadding="0" cellspacing="0" border="0">
		<thead>
        <tr>
          <t>
            <th>ID</th>
            <th>Firstname</th>
            <th>Lastname</th>
            <th>Email</th>
            <th>Student ID</th>
            <th>Location</th>
            <th>IP Address</th>
            <th>Date</th>
            <th>Update Information</th>
          </t>
        </tr>
      </thead>
    </table>
  </div>
  <div class="tbl-content">
    <table cellpadding="0" cellspacing="0" border="0">
      <tbody>

	  <?php
	  
// 	  $search = $_GET["valueSearch"];

// 	  $sql = "SELECT * FROM users WHERE studentIDUSERS = '$search' OR firstnameUsers LIKE '$search' OR lastnameUsers LIKE '$search' OR location LIKE '$search'";

// 	  $outcome = sqlsrv_query($conn, $sql);
// 	  $query = sqlsrv_has_rows($outcome);

// 	  if ($query > 0) {

// 	  while($row = sqlsrv_fetch_array($outcome))
// 	  {
// 		echo "
// 		<p>
// 		".$row['studentIDUSERS']."
// 		".$row['firstnameUsers']."
// 		".$row['lastnameUsers']."
// 		".$row['emailUsers']."
// 		".$row['studentIDUSERS']."
// 		".$row['ipAddressUsers']."
// 		".$row['location']."
// 		</p>"
// 	  }
// }
// else {
// 	echo = ("No record Found");
// }


$search = $_GET["valueSearch"];

$sqlSearch = "SELECT * FROM users WHERE ID LIKE '%$search%' OR firstnameUsers LIKE '%$search%' OR lastnameUsers LIKE '%$search%' OR emailUsers LIKE '%$search%' OR studentIDUSERS LIKE '%$search%'
OR location LIKE '%$search%'";

$outcome = sqlsrv_query($conn, $sqlSearch);
$query = sqlsrv_has_rows($outcome);


while($row = sqlsrv_fetch_array($outcome))
{
  ?>
		<tr>
			<td><?php echo $row['ID']; ?></td>
			<td><?php echo $row['firstnameUsers']; ?></td>
			<td><?php echo $row['lastnameUsers']; ?></td>
			<td><?php echo $row['emailUsers']; ?></td>
			<td><?php echo $row['studentIDUSERS']; ?></td>
			<td><?php echo $row['location']; ?></td>
			<td><?php echo $row['ipAddressUsers']; ?></td>
      <td><?php echo $row['dateUsers'] -> format ('Y-m-d H:i:s'); ?></td>
			<td><a href="update_Database-Handler.php">Update Information</a></td>
		</tr>
		<?php
/* echo "
<p>
".$row['studentIDUSERS']."
".$row['firstnameUsers']."
".$row['lastnameUsers']."
".$row['emailUsers']."
".$row['location']."
".$string = $row['dateUsers'] -> format ('Y-m-d H:i:s')."
</p>";
*/
}


		// $sql = "SELECT * FROM dbo.users";
		// $stmt = sqlsrv_query($conn, $sql);
		// if (!$stmt) {
		// die(print_r(sqlsrv_errors(), true));
// }
		// while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
    ?>
    
	
		<?php
		
		//sqlsrv_free_stmt($stmt);
		?>



      </tbody>
    </table>
  </div>
</section>
</form>
</body>
</html>