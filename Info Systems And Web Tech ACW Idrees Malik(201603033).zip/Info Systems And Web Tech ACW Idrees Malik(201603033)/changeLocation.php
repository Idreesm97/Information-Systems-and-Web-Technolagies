<?php
include "database-Handler.php";
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="ChangeLocation.css">
    <meta charset="utf-8" />
	<title>Info Systems ACW</title>
	<style media="screen">
	  </style>
</head>
<body>
<a href="index.php"><h1>Update Location Page</h1></a>
<br>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$studentID = $_POST['id'];
$Location = $_POST['location'];


$firstname = "SELECT firstnameUsers FROM users WHERE '$studentID' = studentIDUSERS";
$lastname = "SELECT lastnameUsers FROM users WHERE '$studentID' = studentIDUSERS";
$email = "SELECT emailUsers FROM users WHERE '$studentID' = studentIDUSERS";
$ip = "SELECT ipAddressUsers FROM users WHERE '$studentID' = studentIDUSERS";

$firstnameQuery = sqlsrv_query($conn, $firstname);
$lastnameQuery = sqlsrv_query($conn, $lastname);
$emailQuery = sqlsrv_query($conn, $email);
$ipQuery = sqlsrv_query($conn, $ip);

$firstnameFetch = sqlsrv_fetch_array($firstnameQuery);
$lastnameFetch = sqlsrv_fetch_array($lastnameQuery);
$emailFetch = sqlsrv_fetch_array($emailQuery);
$ipFetch  = sqlsrv_fetch_array($ipQuery);

$tsql = "INSERT INTO users(firstnameUsers, lastnameUsers, emailUsers, studentIDUSERS, ipAddressUsers, dateUsers, location) 
VALUES ('$firstnameFetch[firstnameUsers]', 
'$lastnameFetch[lastnameUsers]', 
'$emailFetch[emailUsers]', 
'$studentID', '$ipFetch[ipAddressUsers]' , SYSDATETIME(), '$Location')";

$result = sqlsrv_query($conn, $tsql);
}
/*
if($result)
{
  echo "SUCCESSFUL";
}
else
{
  die(print_r( sqlsrv_errors(), true));
  //echo "NOT SUCCESSFULL";
}
*/


?>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
        <section>
		<div class="input-container">
        <input class="input-field" type="text" placeholder="studentID"  pattern="^[0-9_]{9}$" name="id" required autocomplete="off">
        <span class="error">* <?php?></span>
        <br>
		</div>
        <br>
		<div class="input-container">
        <input class="input-field" type="text" placeholder="Location"  pattern="^[A-Z a-z]{1,20}$" name="location" required autocomplete="off">
        <span class="error">* <?php echo $locationError;?></span>
        <br><br>
		</div>
        <br>
        <div class="mainIndex">
		<div class="sub-mainIndex">
         <button type="submit" name="submit" class="button-two" id="input-submit"><span>Update Something</span></button>
		</div>
		</div>
		</section>
      </form>

</body>
</html>