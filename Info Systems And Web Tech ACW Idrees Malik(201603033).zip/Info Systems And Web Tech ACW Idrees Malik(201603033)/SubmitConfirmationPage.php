﻿<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="SubmitConfirmationPage.css">
    <meta charset="utf-8" />
    <title></title>
    <style>
        .loader {
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #3498db;
            width: 120px;
            height: 120px;
            -webkit-animation: spin 100s linear infinite; /* Safari */
            animation: spin 1.5s linear infinite;
        }

        /* Safari */
        @-webkit-keyframes spin {
            0% {
                -webkit-transform: rotate(0deg);
            }

            100% {
                -webkit-transform: rotate(360deg);
            }
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
</head>
<body>
    <svg class="loader" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
        <circle class="internal-circle" cx="60" cy="60" r="30"></circle>
        <circle class="external-circle" cx="60" cy="60" r="50"></circle>
    </svg>
    
    <?php
    header("refresh:5; url= index.php");
    ?>
    
    


</body>
</html>