﻿<?php
include "database-Handler.php";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>
<form action="searchfunction.php" id="searchform" method="GET" class="searchbox-container">
    <input type="text" id="searchbox" name="searchbox" class="searchbox" />
    <input type="submit" class="searchbox-btn" value="Search" />
    <input type="hidden" name="action" value="search" />

<?php
 
if(isset($_GET['action'])&&isset($_GET['searchbox'])) {
    if($_GET['searchbox']!=null) {
        $result = sqlsrv_query($conn, "SELECT * FROM dbo.users WHERE 'firstnameUsers' LIKE '%{$_GET['searchbox']}%' OR 'lastnameUsers' LIKE '%{$_GET['searchbox']}%'");
		die(print_r(sqlsrv_errors(), true));
		echo "hello";
		$row = sqlsrv_fetch_array($result);
		if ($row) {
		die(print_r(sqlsrv_errors(), true));
		echo "hello";
		echo $row;
}
    } else {
        $result = sqlsrv_query($conn, "SELECT * FROM dbo.users");
		die(print_r(sqlsrv_errors(), true));
		echo "bye";
    }
}
else {
	echo "search box empty";
}

?>
</body>
</html>