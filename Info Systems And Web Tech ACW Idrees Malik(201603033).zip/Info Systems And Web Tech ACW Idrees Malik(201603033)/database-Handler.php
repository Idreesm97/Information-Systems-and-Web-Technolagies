﻿<?php
$dbServername = 'sql.rde.hull.ac.uk';
$conn_Info = array('Database' => 'rde_538629');
$conn = sqlsrv_connect($dbServername, $conn_Info);

if (!$conn) {
  die(print_r(sqlsrv_errors(), true));
}
else {
echo "Databse Connected";
}

 ?>
