<?php
$dbServername = 'sql.rde.hull.ac.uk';
$conn_Info = array('Database' => 'rde_538629');
$conn = sqlsrv_connect($dbServername, $conn_Info);

if($conn){
    echo "Successful Connection";
}
else{
    echo "No Connection";
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="location24hrsDesign.css">
    <meta charset="utf-8" />
	<title>Search Last 24hrs And Current Location</title>
</head>
<body>
<a href="index.php"><h1>Search Last 24Hrs And Current Location</h1></a>
<form action="location.php" method="get">
<input type="text" name="valueSearch" placeholder="Enter Value To Search" pattern="^[A-Z a-z 0-9_]{1,10}$" title="Invalid Input In Search"><br><br>
       <div class="main">
       <div class="sub-main">
         <button type="submit" name="Search" class="button-two" id="search-button"><span>Search Something</span></button>
       </div>
     </div>
        <br><br><br><br><br><br><br>
       <div class="tbl-header">
         <table cellpadding="0" cellspacing="0" border="0">
		<thead>
        <tr>
          <t>
            <th>ID</th>
            <th>Firstname</th>
            <th>Lastname</th>
            <th>Email</th>
            <th>Student ID</th>
            <th>Location</th>
            <th>IP Address</th>
            <th>Date</th>
            <th>Update Information</th>
          </t>
        </tr>
      </thead>
    </table>
  </div>
  <div class="tbl-content">
    <table cellpadding="0" cellspacing="0" border="0">
      <tbody>
<?php
$search = $_GET["valueSearch"];

$sqlSearch = "SELECT * FROM users WHERE (ID LIKE '%$search%' OR firstnameUsers LIKE '%$search%' OR lastnameUsers LIKE '%$search%' OR emailUsers LIKE '%$search%' OR studentIDUSERS LIKE '%$search%'
OR location LIKE '%$search%') AND dateUsers >= DATEADD(day, -1, GETDATE())  ORDER BY 'dateUsers' desc";

$sqlSearchTime = "SELECT * FROM users WHERE dateUsers >= DATEADD(day, -1, GETDATE())";
$outcome = sqlsrv_query($conn, $sqlSearch);
$query = sqlsrv_has_rows($outcome);


while($row = sqlsrv_fetch_array($outcome))
{
  ?>
		<tr>
			<td><?php echo $row['ID']; ?></td>
			<td><?php echo $row['firstnameUsers']; ?></td>
			<td><?php echo $row['lastnameUsers']; ?></td>
			<td><?php echo $row['emailUsers']; ?></td>
			<td><?php echo $row['studentIDUSERS']; ?></td>
			<td><?php echo $row['location']; ?></td>
			<td><?php echo $row['ipAddressUsers']; ?></td>
      <td><?php echo $row['dateUsers'] -> format ('Y-m-d H:i:s'); ?></td>
			<td><a href="update_Database-Handler.php">Update Information</a></td>
		</tr>
    <?php
}
$sqlget = "SELECT * FROM users WHERE dateUsers >= DATEADD(day, -1, GETDATE())";
$stmt_search = sqlsrv_query($conn, $sqlget);

while($row = sqlsrv_fetch_array($stmt_search, SQLSRV_FETCH_ASSOC)){
    ?>
    <tr>
        <td><?php echo $row['ID']; ?></td>
        <td><?php echo $row['firstnameUsers']; ?></td>
        <td><?php echo $row['lastnameUsers']; ?></td>
        <td><?php echo $row['emailUsers']; ?></td>
        <td><?php echo $row['studentIDUSERS']; ?></td>
        <td><?php echo $row['location']; ?></td>
        <td><?php echo $row['ipAddressUsers']; ?></td>
  <td><?php echo $row['dateUsers'] -> format ('Y-m-d H:i:s'); ?></td>
        <td><a href="update_Database-Handler.php">Update Information</a></td>
    </tr>
    <?php
    }
    sqlsrv_free_stmt($stmt);
    ?>
