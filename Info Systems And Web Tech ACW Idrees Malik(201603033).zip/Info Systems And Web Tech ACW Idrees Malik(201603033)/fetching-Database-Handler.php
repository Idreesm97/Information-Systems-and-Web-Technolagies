﻿<?php
//include "database-Handler.php";
$dbServername = 'sql.rde.hull.ac.uk';
$conn_Info = array('Database' => 'rde_538629');
$conn = sqlsrv_connect($dbServername, $conn_Info);
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>
<form action="" method="get">
<input type="text" name="valueSearch" pattern="^[A-Za-z0-9_]{1,20}$"  placeholder="Enter Value To Search"><br><br>
<button type="submit" name="Search">Search</button>
     


<?php

$search = $_GET["valueSearch"];

$sqlSearch = "SELECT * FROM users WHERE studentIDUSERS LIKE '$search'";

$outcome = sqlsrv_query($conn, $sqlSearch);
$query = sqlsrv_has_rows($outcome);

if ($query > 0) {

while($row = sqlsrv_fetch_array($outcome))
{
echo "
<p>
".$row['studentIDUSERS']."
".$row['firstnameUsers']."
".$row['lastnameUsers']."
".$row['emailUsers']."
".$row['location']."
".$string = $row['date'] -> format ('Y-m-d H:i:s')."
</p>";
}
}
else {
echo ("No NO record Found");
}





/*
	$stmt = sqlsrv_query($conn, $sql);
	if (!$stmt) {
	die(print_r(sqlsrv_errors(), true));
}
	while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)){
	?>
		<br>
		<?php echo $row['ID']; ?></td>
		<?php echo $row['firstnameUsers']; ?>
        <?php echo $row['lastnameUsers']; ?>
        <?php echo $row['emailUsers']; ?>
        <?php echo $row['studentIDUSERS']; ?>
        <?php echo $row['location']; ?>
        <?php echo $row['ipAddressUsers']; ?>
		<a href="update_Database-Handler.php">Update Information</a>
	<?php
	}
	sqlsrv_free_stmt($stmt);
	*/
?>
</form>
</body>
</html>